# Latent-Space REINFORCE for Creative 2/6 Generation — Team 3

**Authors:** Haoting Yuan, Gustavo Moreira, Fahmeed Nabi, Bryant Lisk

This submission contains the final mathematical writeup and the two notebooks that, together, implement and evaluate our latent-space REINFORCE framework for generating creative MNIST digits that lie between classes 2 and 6.

## Files

### 1. `Mathematical_Formulation_of_the_Latent_Space_REINFORCE_Framework_Team_3.pdf`

Self-contained mathematical writeup of the method. We reinterpret a standard MDP as a *latent-space control problem*: the state is a VAE latent code `z_t ∈ R^d`, the action is a continuous latent displacement `a_t`, the transition is the deterministic update `z_{t+1} = z_t + η a_t`, and the reward is a handcrafted score on the decoded image `x_t = D(z_t)`. The document covers:

- Problem setup and the one-to-one mapping between standard RL objects and our latent-space objects.
- The diagonal-Gaussian policy `π_θ(a|z) = N(c·tanh(f_θ(z)), diag(exp(2ℓ_θ)))`, with state-dependent mean and a learnable log-std vector.
- The four-term reward: target-class mass `p_2 + p_6`, balance penalty `β(p_2 − p_6)^2`, total-variation smoothness penalty, and an off-target penalty.
- The REINFORCE gradient derivation in this setting and the resulting estimator `∇_θ J = E_τ[Σ_t G_t ∇_θ log π_θ(a_t|z_t)]`.
- Policy-network architecture (`d → h → h → d` MLP with ReLU + tanh head), parameter count, and the role of each hyperparameter (γ, T, η, batch size, learning rate, action scale, return normalization).

### 2. `RL_Image_Mixtures.ipynb`

End-to-end implementation of the framework on MNIST and the latent-dimension comparison study referenced in the writeup. The notebook:

- Defines a small VAE (encoder + decoder) and an MNIST classifier, loads pre-trained VAE checkpoints at `d ∈ {16, 32, 64, 80}`, and encodes reference 2s and 6s.
- Implements the Gaussian policy and the rollout / return / REINFORCE-with-baseline-normalization loop exactly as derived in the PDF.
- Trains policies across all latent dimensions with multiple runs per dimension, logging per-epoch reward and loss curves and saving the full latent → decoded-image trajectory at each epoch.
- Aggregates results (mean ± std reward curves by `d`, final-image grids per run, summary CSVs).
- Includes a creativity-analysis appendix using H1 cubical persistence (via `gudhi`/`persim`) plus the Kynkäänniemi-2019 manifold realism estimator (`ManifoldKNN`), so generated images can be scored on topological novelty and realness in addition to classifier reward.

### 3. `latent_pt_init_and_hyperparam_tuning.ipynb`

The full experimental campaign behind the final presentation. It builds on the framework from notebook 2 and runs four hyperparameter / design sweeps under a stricter, slides-version creativity metric:

- **Shared infrastructure:** trains a VAE on 2s and 6s and a 10-class classifier once, then reuses them throughout.
- **Creativity metric:** `Creativity(x) = R(x) · A(x)^α · N(x)^(1−α)` where realism `R` is the manifold-membership / hypersphere score, ambiguity `A` is normalized binary entropy of `(p_2, p_6)`, and novelty `N` is the realism-gated distance to the nearest training latent. The product form requires all three components to be nontrivial.
- **Baseline:** plain latent interpolation across a full α-sweep, so the RL policy is compared against the best baseline α rather than a single point.
- **Experiment A — latent dim** `d ∈ {16, 32, 64, 148}`.
- **Experiment B — rollout horizon** `T ∈ {5, 10, 20, 40}`, with `step_size` adjusted inversely to keep total walk distance constant.
- **Experiment C — initialization** of `z_0`: fixed-α interpolation, centroid interpolation, semantic walk from an anchor, and energy-minimizing geodesic midpoints.
- **Experiment D — learning rate / scheduler:** constant, cosine, and warmup-cosine.
- **Final head-to-head:** picks the best configuration, runs many evaluation rollouts, and produces the side-by-side gallery and summary table comparing RL output to the peak-α baseline under the creativity metric.

A key design choice is that we *train* on the classifier-based reward from the writeup but *evaluate* under the stricter creativity metric — separating the two lets us check whether the policy is gaming the reward or producing genuinely creative samples.

## Reproduction

Both notebooks are intended to be run top-to-bottom. They depend on `torch`, `torchvision`, `numpy`, `pandas`, `matplotlib`, `scikit-learn`, and (for the topological appendix in notebook 2) `gudhi` and `persim`. MNIST is downloaded automatically. A `SPEED_MODE` flag in notebook 3 toggles a fast configuration for quick verification versus the full sweep used for the presentation.
